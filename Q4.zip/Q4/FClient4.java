//frame  and ack loss
import java.net.*;
import java.io.*;
import java.util.*;

public class FClient4 {
	
 private static final double LOSS_RATE = 0.3;
	public static void main(String[] args) {

	    DatagramSocket cs = null;
		FileOutputStream fos = null;
		Random random = new Random();


		try {

			System.out.println("Client is ready ! ");
         		System.out.println(" REQUEST"+"file "+"\t\n");

	    		cs = new DatagramSocket();
            		cs.setSoTimeout(3000);
        		byte[] rd, sd;
			String reply;
			DatagramPacket sp,rp;
			int count=1;
			boolean end = false;

			// write received data into demoText1.html
			fos = new FileOutputStream(args[2]);

			while(!end)
			{
			    String ack = "" + count;

				// send ACK
			    sd=ack.getBytes();
			    sp=new DatagramPacket(sd,sd.length,
									  InetAddress.getByName(args[0]),
  									  Integer.parseInt(args[1]));
                try{
				cs.send(sp);
                     System.out.print("ACK"+count+"\t\n");

				// get next consignment
				rd=new byte[512];
				rp=new DatagramPacket(rd,rd.length);
			   // try
			   // {

			    cs.receive(rp);
                   
				if (random.nextDouble() < LOSS_RATE)
                {
                System.out.println("   Acknowledegement Signal with sequence number:"+(count+1)+" was lost while sending ! Waiting for server to resend....");
                    cs.send(sp);
               //  continue;
                 }

				// concat consignment
			    reply=new String(rp.getData());
                    if(reply.indexOf("ENDOF")!=-1)
                        break;
                //byte reply1[]=rp.getData();

			  //  System.out.println(reply);
			   // if(count<=7)
                
               // System.out.print("ACK"+count+"\t\n");
                
				fos.write(rp.getData());

				//if (reply.indexOf("END")!=-1 && count>7)                 //reply.trim().equals("END")) // if last consignment
				//	break;
			    }
			    catch(SocketTimeoutException ex)
			{
				System.out.println("Time out ! Did not recieve packet !");
                    //count--;
				if(count==16)
                    end=true;
			}finally{
				count++;
                }
			}

		} catch (IOException ex) {
			System.out.println(ex.getMessage());

		} finally {

			try {
				if (fos != null)
					fos.close();
				if (cs != null)
					cs.close();
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
			}
		}
	}
}
