//frme loss

import java.net.*;
import java.io.*;
import java.util.*;

public class FServer4
{
	private static final double LOSS_RATE = 0.3;
  	private static final int AVERAGE_DELAY = 100;  // milliseconds

	public static void main(String[] args) {

		DatagramSocket ss = null;
		FileInputStream fis = null;
		DatagramPacket rp, sp=null;
		byte[] rd, sd;
         	//int flag=0;
		InetAddress ip;
		int port;
		int counter=1;
		 int total=1;
        	int extra =1;
     		Random random = new Random();

		try {
			ss = new DatagramSocket(Integer.parseInt(args[0]));
			System.out.println("Server is up....");
			System.out.println("Intiating RDT protocl.Waiting for Client to start....");


			// read file into buffer
			fis = new FileInputStream(args[1]);

			int consignment;
			String strConsignment;
			int result = 0; // number of bytes read
			boolean flag = false;

			while(true && result!=-1){

				rd=new byte[100];
				sd=new byte[512];

				rp = new DatagramPacket(rd,rd.length);
	try
                {

				ss.receive(rp);
               if (random.nextDouble() < LOSS_RATE)
                {
                System.out.println("   Reply not sent.");
                 // flag=true;
                   counter--;
               continue;
                 }


				// get client's consignment request from DatagramPacket
				ip = rp.getAddress();
				port =rp.getPort();
				System.out.println("Client IP Address = " + ip);
				System.out.println("Client port = " + port);
        System.out.println("RDT "+counter);

				strConsignment = new String(rp.getData());
				consignment = Integer.parseInt(strConsignment.trim());
				/*if(counter>=8  )
                {
                System.out.println("END ");
                    break;
		//total++;
                }*/
				// prepare data
				result = fis.read(sd);
				if (result == -1) {
					sd = new String("ENDOF").getBytes();
                    System.out.println("END");
					consignment = -1;
				}
				sp=new DatagramPacket(sd,sd.length,ip,port);
             
               // if(counter==consignment)
				ss.send(sp);
                flag=false;
				rp=null;
				sp = null;
	}
	catch(SocketTimeoutException ex)
			{
				System.out.println("Protocol timed out ! Did not recieve ACK signal . Resending frame :"+counter+" again in few  seconds....");
                flag=true;
			}finally{
             if(flag==false)
             counter++;
           }
			}

		}
		 catch (IOException ex) {
			System.out.println(ex.getMessage());

		}
		finally {
			try {
				if (fis != null)
					fis.close();
			} catch (IOException ex) {
				System.out.println(ex.getMessage());
			}
		}

	}

}

